$(document).ready(function() {
  console.log("llamando");
  // $('#carouselExampleIndicators').carousel()
  $('.carousel').carousel()
  // $('#myCarousel').carousel({
  // pause: 'none'
  // })
});